package com.company;

public class Third {
}
